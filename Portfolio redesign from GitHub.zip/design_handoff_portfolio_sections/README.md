# Handoff: About · Experience · Education & Recognition redesign

Repo: `KamleshKumar427/Kumars-Portfolio` (Vite + React + TS, all styles in `src/index.css`). Read `.claude/brain/design-system.md` first.

## Prompt to paste into Claude Code

> Implement the design in `design_handoff_portfolio_sections/` across the site. Read this README in full, then open `Final Sections.dc.html` in a browser as the visual reference (light and dark are shown side by side).
>
> **Presentation only. Do not change any copy or figures.** Leave every string in `src/data/*.ts` as it is: about text, glance rows, role summaries, points, stats, tech, education, recognition. The HTML shows the current site copy, used only to make the mock realistic. The one data change allowed is adding a portrait image path (see Assets).
>
> Scope:
> 1. `AboutSection.tsx` + its CSS: portrait layout with hanging quote marks, a seal stamp, and a 2×3 glance grid.
> 2. `WorkSection.tsx` + `.work-row` CSS: the figures move out of the body into the left rail ("margin notes").
> 3. `PathSection.tsx` and `RecognitionSection.tsx`: replace the boxed `.stat` tiles with the "ledger" treatment.
> 4. Retire the old boxed `.stat` look (`--stat-bg/--stat-border/--stat-shadow` tiles) everywhere it is used. `.cert` cards can keep their surface.
> 5. Light **and** dark themes (`[data-theme]` tokens already exist), plus phone (390px) and desktop (1440px). Follow the quality floor in design-system.md: reduced motion, 12px minimum text, 4.5:1 contrast, focus rings.
> 6. Use existing tokens. Don't introduce raw hex values; map them using the table below. Update `.claude/brain/design-system.md` with the new patterns (Portrait, Margin figures, Ledger figures), and remove the "Stat tiles" pattern.
> 7. Run `npm run shots` and check both themes before finishing.

## About the design files
`Final Sections.dc.html` is an **HTML design reference**, not production code. Recreate it in the existing React components and `index.css` using the repo's patterns (`.section`, `.section-inner`, `<Reveal>`, the tokens). Inline styles in the reference map to classes in `index.css`. To view it, open the file with `support.js` next to it.

## Fidelity
High fidelity. Final spacing, type, colour and interactions. Sizes below are desktop. On phones, collapse each layout as described under Responsive.

## Token mapping (reference var → repo token)
| Reference | Light | Dark | Repo token |
|---|---|---|---|
| --paper | #f9fcf7 | #141519 | `--paper` / `--bg` |
| --alt | #f4faf1 | #1b1c20 | `section--alt` band |
| --ink | #161a17 | #ecebe6 | `--ink` / `--text` |
| --ink2 | #566150 | #9b9ca3 | `--ink2` / `--text-2` |
| --body | #2f3a2c | #c9c9ce | `--text-body` |
| --line | #dfecd9 | rgba(235,236,240,.12) | `--line` / `--separator` |
| --border | #d3e3cb | rgba(235,236,240,.14) | reuse `--stat-border` value as a hairline token (rename e.g. `--hairline-strong`) |
| --rule | #161a17 | rgba(236,235,230,.75) | **new** `--rule`: the strong ink line over each ledger figure. Add to all 3 theme blocks |
| --seal | #b23a2e | #e2573f | `--seal` / `--accent` |
| --seal-ink | #f6fbf4 | #0f1013 | `--seal-ink` |
| --hover | rgba(24,60,28,.035) | rgba(255,255,255,.03) | `--hover` |
| --photo | #e6ece2 | #1d1e23 | **new** `--photo-bg` (image placeholder while loading) |
| --led | #3aa45a | #4cc46e | existing `.status-led` |

Font: `--font-sans` (system) everywhere. The only exception is the quote marks, which use a serif (`Georgia, 'Times New Roman', serif`) so they read as typographic quotes.

## 1. About (`#about`)
**Layout:** grid `360px | 1fr`, gap 80px, align start. The section keeps the existing section padding (the reference card uses 80px/64px).

**Portrait column**
- Wrapper `position:relative`, 360×450 (aspect 4:5). Inner box `border-radius: var(--r-md)` (14px), `overflow:hidden`, background `--photo-bg`.
- `<img>`: `object-fit:cover; object-position:50% 30%`. Default `filter: grayscale(1) contrast(1.08) brightness(.96)`.
- **Hover** (on the img or wrapper, and also `:focus-visible` on the wrapper if it's focusable): `filter: grayscale(0) contrast(1) brightness(1); transform: scale(1.03)`. Transition `filter .8s, transform .8s` with `var(--ease)`. Touch devices (`hover:none`): show in colour, or keep greyscale; your choice, but don't leave a sticky hover. Reduced motion: no scale, filter change only.
- **Seal stamp:** absolutely positioned at `left:-22px; bottom:-22px`, 64×64, background `--seal`, colour `--seal-ink`, radius 6px, `rotate(-5deg)`, font 26px/700, glyph 印, `box-shadow: 0 6px 18px -8px rgba(0,0,0,.45)`, `pointer-events:none`, `aria-hidden`. It must not cause horizontal overflow on phones (inset it to `left:12px` there).
- Caption under the photo, right-aligned, 8px extra top padding: name · city. Build it from `profile.name` and `profile.location`'s city. 12px, uppercase, tracking .08em, `--ink2`.

**Text column** (flex column, gap 40px)
- Kicker: existing `.section-kicker` (私 — About).
- Statement block: `position:relative; padding-top:28px`.
  - Opening mark “: absolute `left:-6px; top:-18px`, serif, 96px, line-height 1, `--seal`, full opacity, `aria-hidden`.
  - `<p>` (or `<blockquote>`) with `profile.about`: 32px (use `clamp(1.5rem, 3vw, 2rem)`), weight 500, line-height 1.34, letter-spacing -0.02em, `text-wrap: pretty`, colour `--ink`.
  - Closing mark ” inline at the end of the text, serif, `--seal`, margin-left 2px, `aria-hidden`.
  - Replaces the old `.about-quote::before/::after` faint 20%-opacity marks and the `max-width:17.5em` constraint.
- **Glance grid** (`profile.glance`, all 6 rows, same order): `dl` grid with 2 equal columns, column-gap 40px, no row gap.
  - Each item: flex column, gap 6px, padding 18px 0, `border-top:1px solid var(--line)`. The last row (items 5–6) also gets `border-bottom`.
  - **The first two items** (Open to, Aspiring) are emphasised: `border-top` uses `--rule` (strong ink), the label is in `--seal`, and the value has weight 600.
  - Other items: label `--ink2`, value weight 400.
  - Label `dt`: 12px uppercase, tracking .08em. Value `dd`: 17px, margin 0.
  - The `led` row keeps the green dot: 8×8 circle, `box-shadow:0 0 0 3px rgba(58,164,90,.2)`, gap 9px before the text.

**Responsive:** ≤900px stacks the photo above the text (photo max-width 320px). ≤560px makes the glance grid 1 column.

## 2. Experience: margin notes (`#experience`)
Same `.work-row`, but the rail widens and holds the figures.
- Row grid: `190px | 1fr`, gap 56px, padding `46px 60px 46px 20px` (right padding leaves room for the arrow), `border-top:1px solid var(--line)`.
- Hover: keep the existing `background: var(--hover)` and `inset 3px 0 0 var(--seal)`. The ↗ arrow sits at `right:22px; top:46px`, 22px, `--seal`. The current fade-in-on-hover is fine to keep.
- **Rail** (flex column, gap 14px): `.work-num` (50px/600, `--seal`), then `.work-meta` (12px, tracking .08em, line-height 1.9, `white-space:nowrap`), then the **figures list**:
  - `margin-top:16px; border-top:1px solid var(--rule)`.
  - Each figure: flex column, gap 4px, padding 13px 0, `border-bottom:1px solid var(--hairline-strong)`.
  - Value: 24px/600, line-height 1.1, letter-spacing -0.025em, tabular-nums, `--ink` (**not** red any more; red is reserved for the role number), `text-wrap:balance`.
  - Label: 12px uppercase, tracking .06em, line-height 1.35, `--ink2`.
- **Body:** kicker, title, summary, points, tags as today. The `stat-row` is removed from the body. Points keep the bold `Label:` split (`splitPoint`) and the ◇ marker. Points max-width 40em. Tech `.tag` gets `white-space:nowrap`.
- Responsive ≤900px: the rail becomes a top block. The number and meta sit in a row, and the figures become a 2-column grid below them (same ledger styling, border-top `--rule`), before the kicker. ≤560px: everything is one column, and the figures stay 2-up.

## 3. Ledger figures: Education (`#education`) and Recognition (`#recognition`)
Replaces `.stat-row/.stat` in `PathSection` and `RecognitionSection`.
- Container: `display:grid; grid-template-columns: repeat(N, minmax(0,1fr))`, where N = number of stats (max 4; use `repeat(auto-fit, minmax(140px,1fr))` if simpler). Gap 28px, margin `18px 0 10px`.
- Cell: `border-top:1px solid var(--rule); padding-top:12px`, flex column, gap 7px, left-aligned. No background, border box, shadow or radius.
- Value: 28px/600, line-height 1.05, letter-spacing -0.03em, tabular-nums, `--ink`, `text-wrap:balance`.
- Label: 12px uppercase, tracking .08em, line-height 1.4, `--ink2`.
- ≤640px: 2 columns.
- Everything else in those sections (edu head, school, focus, points, chips, proof links; honour rail and body) stays as it is.
- Also apply this to the `/startups` page if it uses `.stat-row` (check `StartupsPage.tsx`), so there's one figure style site-wide.

## Interactions
- Portrait hover: greyscale → colour + 1.03 scale, 0.8s `var(--ease)`.
- Work row hover: existing background + inset seal bar + arrow.
- No other new motion. Wrap the new blocks in `<Reveal>`, as the sections already do.

## Assets
- `images/kamlesh-portrait.png` (800×800): copy to `public/images/about/portrait.png` (convert to WebP/AVIF too, keeping a fallback). Add a field like `profile.portrait = { src, alt: 'Kamlesh Kumar' }`; this is the one allowed data addition. Use `loading="lazy"`, explicit width/height, and `decoding="async"`.
- Glyphs used: 私 選 道 誉 印 ◇ ↗ “ ”. No icon files.

## Files
- `Final Sections.dc.html`: the design reference (needs `support.js` beside it).
- `support.js`: the runtime for viewing the reference only. Do not ship it.
- `images/kamlesh-portrait.png`: the portrait.
